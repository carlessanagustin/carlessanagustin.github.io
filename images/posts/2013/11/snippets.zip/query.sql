# this is the right way
SELECT SQL_CALC_FOUND_ROWS
a.`id_product`,b.name as name,`reference`,a.price as price,a.active as active
/* new line */
 , fl.value `feature`

, MAX(i.id_image) id_image,cl.name `name_category` , a.`price`, 0 AS price_final, sav.`quantity` as sav_quantity, a.`active`
FROM `ps_product` a 

LEFT JOIN `ps_product_lang` b ON (b.`id_product` = a.`id_product` AND b.`id_lang` = 1 AND b.`id_shop` = 1)
LEFT JOIN `ps_image` i ON (i.`id_product` = a.`id_product`  AND i.cover=1) 
/* new line */
 LEFT JOIN `ps_feature_product` fp ON (fp.`id_product` = a.`id_product` AND fp.`id_feature` = 6) 
 LEFT JOIN `ps_feature_value_lang` fl ON (fp.`id_feature_value` = fl.`id_feature_value` AND b.`id_lang` = fl.`id_lang`) 

LEFT JOIN `ps_category_lang` cl ON (a.`id_category_default` = cl.`id_category` AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = 1)
LEFT JOIN `ps_stock_available` sav ON (sav.`id_product` = a.`id_product` AND sav.`id_product_attribute` = 0 AND sav.id_shop = 1 )  
WHERE 1 
GROUP BY a.id_product 
ORDER BY a.id_product ASC LIMIT 0,50
